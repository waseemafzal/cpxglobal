<style>
.sf-menu ul li a:hover {
    background: #922d2d;
    color: #111;
}
ul.sf-menu>li>a {
    color: #666;
    font-size: 13px;
}
</style>
<nav class="top-menu">
            <div class="nav-inner">
                <div class="container" >
                    <div class="row">
                        <div class="col-md-12 menu">
                            <div id="mobnav-btn"></div>
                            <ul class="sf-menu" data-breakpoint="800" id="menu-main-menu">
                                
                                <li class="menu-item menu-item-type-post_type menu-item-object-page  "  >
                                    <a href="index.php">Home</a>
                                </li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-332" id="menu-item-332">
                                    <a href="#">About Us</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-299 current_page_item menu-item-301" id="menu-item-301">
                                            <a href="why">Why CPPEx Global</a>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-288" id="menu-item-288">
                                            <a href="mission"> Mission & Vission</a>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-289" id="menu-item-289">
                                            <a href="history">History</a>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-537" id="menu-item-537">
                                            <a href="team"> Our Team</a>
                                        </li>
                                      <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-537" id="menu-item-537">
                                            <a href="contact"> Our Global Presence</a>
                                        </li>
                                      <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-537" id="menu-item-537">
                                            <a href="faq"> Faqs</a>
                                        </li>
                                        
                                      <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-537" id="menu-item-537">
                                            <a href="press_release"> Press Release</a>
                                        </li>
                                        
                                       
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-255" id="menu-item-255">
                                    <a href="training">Training</a>
                                    <ul class="sub-menu">
                                        
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-246" id="menu-item-246">
                                            <a href="javascript:void(0)">Training</a>
    <ul class="sub-menu training">
    
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="cylinder-quality-management"><?=ucwords(str_replace('-', ' ','cylinder-quality-management'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="doctor-blade-print-management
"><?=ucwords(str_replace('-', ' ','doctor-blade-print-management
'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="eco-printing-by-pollution-prevention
"><?=ucwords(str_replace('-', ' ','eco-printing-by-pollution-prevention
'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="effective-colors-management
"><?=ucwords(str_replace('-', ' ','effective-colors-management
'))?></a>
    </li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="excellence-in-lean-print-manufacturing
"><?=ucwords(str_replace('-', ' ','excellence-in-lean-print-manufacturing
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="excellence-in-flexographic-printing
"><?=ucwords(str_replace('-', ' ','excellence-in-flexographic-printing
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="excellence-in-gravure-printing
"><?=ucwords(str_replace('-', ' ','excellence-in-gravure-printing
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="excellence-in-offset-printing
"><?=ucwords(str_replace('-', ' ','excellence-in-offset-printing
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="flexoplate-quality-management
"><?=ucwords(str_replace('-', ' ','flexoplate-quality-management
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="food-safety-packaging-materials
"><?=ucwords(str_replace('-', ' ','food-safety-packaging-materials
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="graphic-design-for-non-designer
"><?=ucwords(str_replace('-', ' ','graphic-design-for-non-designer
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="hazardous-chemicals-management"><?=ucwords(str_replace('-', ' ','hazardous-chemicals-management'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="paper-quality-management"><?=ucwords(str_replace('-', ' ','paper-quality-management'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="prepress-and-packaging-design
"><?=ucwords(str_replace('-', ' ','prepress-and-packaging-design
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="print-automation-and-digitalization"><?=ucwords(str_replace('-', ' ','print-automation-and-digitalization'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="print-quality-management"><?=ucwords(str_replace('-', ' ','print-quality-management'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="printing-process-equipment-validation
"><?=ucwords(str_replace('-', ' ','printing-process-equipment-validation
'))?></a></li>
   <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="uht-processing-and-aseptic-packaging"><?=ucwords(str_replace('-', ' ','UHT-processing-and-aseptic-packaging'))?></a></li>
    
    
    </ul>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-246" id="menu-item-246">
                                            <a href="javascript:void(0)">Certifications</a>
                                             <ul class="sub-menu">
    
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="certifications-overview"><?=ucwords(str_replace('-', ' ','certifications-overview'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="certification-process"><?=ucwords(str_replace('-', ' ','certification-process'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="certifications-benefits"><?=ucwords(str_replace('-', ' ','certifications-benefits'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="eligibility-requirments"><?=ucwords(str_replace('-', ' ','eligibility-requirments'))?></a>
    </li> <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="application-payment"><?=ucwords(str_replace('-', ' ','application-payment'))?></a>
    </li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page ">
    <a href="complaint-process"><?=ucwords(str_replace('-', ' ','complaint-process'))?></a>
    </li>
    </ul>
                                        </li>
                                        
                                    </ul>
                                </li>
                                
                                
                                 <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" >
                                    <a href="#">Consultancy</a>
                                    <ul class="sub-menu">
                                        
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="business-development">Business Development</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="product-development">New Product Development</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="business-innovation">Business Innovation</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="process-optimization">Process Optimization</a>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="markete-analysis">Market Analysis</a>
                                        </li>
                                    </ul>
                                </li>
                                
                                 
                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" >
                                    <a href="#">Membership</a>
                                    <ul class="sub-menu">
                                        
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="why-membership">Why Our Membership</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="membership-categories">Membership Categories</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="membership-benefits">Membership Benefits</a>
                                        </li>
                                        <?php 
                                        if(!empty($this->session->userdata('userlogin')) and  !empty($this->session->userdata('user_id')))
										{
											if(is_exist('','','tbl_membershippackage',
											array('user_id'=>$this->session->userdata('user_id'),'payment_status'=>1))==0)
											{
										?>	
                                               
                                       <?php 
											}
									   }
									   ?> 
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                                    <a href="membership/form">Membership Form</a>
                                                </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="membership_List">Membership List</a>
                                        </li>
                                      
                                    </ul>
                                </li>
                               
                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" >
                                    <a href="#">Affiliations</a>
                                    <ul class="sub-menu">
                                        
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="customers">Customers</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="partners">Partners</a>
                                        </li>
                                      
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" >
                                    <a href="awards">Awards</a>
                                    <ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page ">
<a href="best-machine-operator-award"><?=ucwords(str_replace('-', ' ','best-operator-award'))?></a>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page ">
<a href="award-eligibility"><?=ucwords(str_replace('-', ' ','award-eligibility'))?></a>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page ">
<a href="selection-criteria"><?=ucwords(str_replace('-', ' ','selection-criteria'))?></a>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page ">
<a href="benefits-of-awards"><?=ucwords(str_replace('-', ' ','benefits-of-awards'))?></a>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page ">
<a href="application-process"><?=ucwords(str_replace('-', ' ','application-process'))?></a>
</li>
                              <!--          <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="awards">
                                            Best Machine Opertor Award
                                            </a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="awards/application">Application Process</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="awards/eligibility">Awards Eligibility</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="awards/selection">Awards Selection</a>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="awards/benefits"> Benefits of Awards</a>
                                        </li>-->
                                    </ul>
                                </li>
                              
                                    <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" >
                                    <a href="#">Gallery</a>
                                    <ul class="sub-menu">
                                        <?php 
										 echo getGalleryYear();
										?>
                                       <!-- <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="GalleryYear/view/2019">2019</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="GalleryYear/view/2020">2020</a>
                                        </li>-->
                                      
                                    </ul>
                                </li>
                              <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children" >
                                    <a href="#">Events</a>
                                    <ul class="sub-menu">
                                        
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="events/view/2019">Calender-2019</a>
                                        </li>
                                       <li class="menu-item menu-item-type-post_type menu-item-object-page" >
                                            <a href="events/view/2020">Calender-2020</a>
                                        </li>
                                      
                                    </ul>
                                </li>  
                               
                                 
                                <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-255" >
                                    <a href="contact">Contact</a>
                                    <ul class="sub-menu">
                                        
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-246" >
                                            <a href="contact/registration">Registration</a>
                                        </li>
                                      <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-246" >
                                            <a href="contact/feedback">Feedback</a>
                                        </li>
                                         
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-246">
                                            <a href="contact/complaint">Complaint</a>
                                        </li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-246">
                                            <a href="contact/index">Contact Us</a>
                                        </li>
                                        
                                    </ul>
                                </li>
                                
                            </ul>
                            <!-- End search -->
                        </div>
                    </div><!-- End row -->
                </div><!-- End container -->
            </div>
        </nav>