<?php 
include_once"header.php";
?>
<style>
label {
    font-weight: normal;
}
#slect{
width: 80%;
    padding: 12px 5px;
    float: left;
    border-radius: 0
	}

	.vc_custom_1456124843800 
	{
		padding-top: 20px !important;
		background-color: #80808066 !important;
    }
	#form1 select
	{
		width: 100%;
		border-radius:0px!important;
		color: #a0a0a0;
		height: 44px;
		font-size: 14px;
		font-weight: 400;
		margin-bottom: 25px;
		font-family: Arial, sans-serif;
		line-height: 1.428571429;
		padding: 6px 12px;    border-color: #a4a4a44a;
	}

		.register:hover
		{
			color: #fff;
			background-color:#f30100	
		}
		.register
		{    
			border: 1px solid #f30100;
			padding: 5px 25px;
			color: #000;
		}
		.btn 
			{
			height: 44px;
			border: none;
			background-color: #f30100;
			color: #fff;
			-webkit-border-radius: 0px;
			-moz-border-radius: 0px;
			border-radius: 0px;
		  }
		  
		textarea 
		{
			height: auto;
		}

	.vc_custom_1456124843800 {
    padding-top: 20px !important;
    background-color: #80808066 !important;
}
#form1 select
{width: 100%;
border-radius:0px!important;
    color: #a0a0a0;
    height: 44px;
    font-size: 14px;
    font-weight: 400;
    margin-bottom: 25px;
    font-family: Arial, sans-serif;
    line-height: 1.428571429;
    padding: 6px 12px;    border-color: #a4a4a44a;
}

.register:hover{
	color: #fff;
		
	}
.register{ 
background-color:#f30100;
   border: 1px solid #f30100;
    padding: 5px 25px;
	font-weight:bold;
    color: #000;}
.btn {
    height: 44px;
    border: none;
    background-color: #f30100;
    color: #fff;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
} textarea {
    height: auto;
}
form label{
	margin-left:2px;
	}
.vc_custom_1456124843800 {
    padding-top: 20px !important;
    background-color: #80808066 !important;
    position: absolute;
    z-index: 1;
    top: 166px;
    width: 100%;
}
.wpb_wrapper h4 {
   
    text-transform: uppercase;
}
</style>
        <section class="hidden" id="sub-header" style="background:url('frontend/contactus.png')">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
            <h1>CONTACT
            </h1>
</div>
            </div><!-- End row -->
        </div><!-- End container -->
      </section>
     
<section style="padding-top: 0px !important;" class="vc_rows wpb_rows vc_rows-fluid vc_custom_1488790902404 contactPage" id="main-features">
     
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3079.2825426358527!2d-75.02054198526999!3d39.485534219667585!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c732633a6b5ea5%3A0x76467bbc01e883c8!2s807%20E%20Landis%20Ave%2C%20Vineland%2C%20NJ%2008360%2C%20USA!5e0!3m2!1sen!2s!4v1582635745886!5m2!1sen!2s"  height="250" frameborder="0" style="border:0;" class="col-xs-12 col-md-12 USA" allowfullscreen=""></iframe>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3660.4139915730757!2d-47.467489885546165!3d-23.445526863208645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c5f59ef6749dd1%3A0x7ada188965a4cb6d!2sR.%20Tereza%20de%20Jesus%20Pinto%2C%20170%20-%20Jardim%20Santa%20Catarina%2C%20Sorocaba%20-%20SP%2C%2018078-698%2C%20Brazil!5e0!3m2!1sen!2s!4v1582889224980!5m2!1sen!2s" class="col-xs-12 col-md-12 AMERICA hidden"  height="250" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d43303.57672478974!2d5.023507910551539!3d47.28554488983296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f29e92273d8339%3A0x693ac3d662282782!2s21600%20Longvic%2C%20France!5e0!3m2!1sen!2s!4v1582889535670!5m2!1sen!2s" height="250" class="col-xs-12 col-md-12 hidden EUROPE"  frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3402.955366164483!2d74.24913471448151!3d31.470413956757334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39190225a74496b5%3A0x27c8247117eae3ee!2s92%20J1-%2C%20Block%20J1%20Block%20J%201%20Phase%202%20Johar%20Town%2C%20Lahore%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1582889654685!5m2!1sen!2s" height="250" class="col-xs-12 col-md-12 SOUTH hidden"  frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3608.4366713143186!2d55.29862301432857!3d25.255892035515945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43254a63a02d%3A0x99a61aee5dd27061!2sBusiness%20Time%20Business%20Center%20Bur%20Dubai!5e0!3m2!1sen!2s!4v1582890094064!5m2!1sen!2s" height="250" class="col-xs-12 col-md-12 hidden MIDDLE  hidden"  frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            <div style="position:relative">
            <section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1456124843800"> 
           <div class="container"><div class="row">
           <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-md-offset-2 vc_col-md-8"><div class="vc_column-inner">
           <div class="wpb_wrapper">
      <select style="color:#595959 !important"  onChange="getDirection(this.value)"id="slect" >
      <option >Select</option>
      <option value="USA">USA</option>
      <option value="EUROPE">Europe</option>
      <option value="SOUTH">South Asia</option>
      <option value="MIDDLE">Middle East</option>
      <option value="AMERICA">South America</option>
      </select>
  <span class="input-group-btn">
        <button class="btn" type="submit">GET DIRECTIONS</button>
      </span>
<div class="clearfix">&nbsp;</div>
            
  </div>
  </div></div></div></div>
  </section>
            </div>
           <div class="clearfix">&nbsp;</div>
        <div class="container">
            
           <div class="col-md-4 col-xs-12">
           <div class="wpb_wrapper">
			<div class="USA ">
            <h4> USA</h4>
<ul id="contact-info">
<li><i class="icon-home"></i> 807 E Landis Ave.Vineland, 08360 New JERSEY-USA</li>
<li><i class="icon-phone"></i> (856) 839-2373</li>
<li><i class="fa fa-fax"></i> (856) 839-2374</li>
<li><i class="icon-mobile"></i> 0016092712476</li>
<li><i class=" icon-email"></i> <a href="#">info@cppexglobal.org</a></li>
</ul>
            </div>
            <div class="AMERICA hidden">
            <h4> South America</h4>
<ul id="contact-info">
<li><i class="icon-home"></i> Rua Tereza de Jesus Pinto.170. Sorocaba, Sao Paulo - Brazil.</li>
<li><i class="icon-mobile"></i> +55 1598 173 0421</li>
<li><i class=" icon-email"></i> <a href="#">info@cppexglobal.org</a></li>
</ul>
            </div>
            <div class="EUROPE hidden">
            <h4> EUROPE</h4>
<ul id="contact-info">
<li><i class="icon-home"></i> Longvic City- 21600, Dijon - France</li>
<li><i class="icon-mobile"></i> +33 (0) 68 100 4157</li>
<li><i class=" icon-email"></i> <a href="#">info@cppexglobal.org</a></li>
</ul>
            </div>
            <div class="SOUTH hidden" >
            <h4> South Asia</h4>
<ul id="contact-info">
<li><i class="icon-home"></i> 92-J 1 Sunflower Society, Johar Town, Lahore –Pakistan</li>
<li><i class="icon-phone"></i> +92 42 3705 8294</li>
<li><i class="icon-mobile"></i>+92 300 846 4155</li>
<li><i class=" icon-email"></i> <a href="#">info@cppexglobal.org</a></li>
</ul>
            </div>
            <div class="MIDDLE hidden" >
            <h4> Middle East & Africe 
</h4>
<ul id="contact-info">
<li><i class="icon-home"></i> Royal Business centre-Al Abbas Building 2, Bank Street Burjuman, Dubai

</li>
<li><i class="icon-phone"></i> +97 155 523 3367</li>
<li><i class="icon-mobile"></i>+966 59 747 1130</li>
<li><i class=" icon-email"></i> <a href="#">info@cppexglobal.org</a></li>
</ul>
            </div>
<hr>
<h4>Follow us</h4>
<p>Connect, follow and have a conversation with us for latest News, articles, blogs, customer service, industry insight, career opportunities, working life, education, expert advice and corporate values on social medial.
</p>
<ul id="follow_us_contacts">
<li><a href="httpss://fb.com/CPPExGlobal"><i class="icon-facebook"></i>fb.com/CPPEx Global</a></li>
<li><a href="httpss://twitter.com/CPPExGlobal"><i class="icon-twitter"></i>twitter.com/CPPEx Global</a></li>
<li><a href="httpss://googleplus.com/CPPExGlobal"><i class=" icon-google"></i>googleplus.com/CPPEx Global</a></li>
<li><a href="httpss://linkedin.com/CPPExGlobal"><i class=" icon-linkedin"></i>linkedin.com/CPPEx Global</a></li>
<li><a href="httpss://youtube.com/CPPExGlobal"><i class=" icon-youtube"></i>youtube.com/CPPEx Global</a></li>
</ul>
<hr style="margin-bottom:4px">
<p>The CPPEx Global helpline offers guidance and advice about the Training & consultancy 
services. This service is available from 9.30am – 5.00pm (as per local time) Monday to Friday by 
calling in Head Office or Branch offices. Outside of these hours please complete the form above, 
or email your questions to info@cppexglobal.org  The CPPEx Global welcomes feedback on 
any aspects of the operation of training and consultancy services.</p>

		</div>
           </div>
           <div class="col-md-8 col-xs-12 " >
           <div class="" id="contactform" >

           <form id="form1" name="form_add_update" method="post" action="">
          	 	 	 	 
            <section id="personalDetail" >
                <div class="col-md-12 col-xs-12"><h4>CONTACT US</h4></div>
                <div class="col-md-4 col-xs-12">
                <label>First Name <span class="text-danger">*</span></label>
                <input class="form-control"  required="required" name="firstname" />
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Last Name <span class="text-danger">*</span></label>
                <input class="form-control" required name="lastname" />
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Email <span class="text-danger">*</span></label>
                <input class="form-control" type="email" required name="email" />
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Company <span class="text-danger">*</span></label>
                <input class="form-control" required name="otherinfo[company_name]" />
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Business Phone <span class="text-danger">*</span></label>
                <input class="form-control" required name="otherinfo[bussinuss_phone]" />
                </div>
                <div class="col-md-4 col-xs-12">
                <label>What is your industry?</label>
                    <select  name="otherinfo[industry]">
                        <option>----</option>
                        <option value="Printing Industry">Printing Industry</option>
                        <option value="Paints Industry">Paints Industry</option>
                        <option value="Printing Ink Industry">Printing Ink Industry</option>
                        <option value="Paper Industry">Paper Industry</option>
                        <option value="Plastic Industry">Plastic Industry</option>
                        <option value="Packaging Industry">Packaging Industry</option>
                        <option value="Food Industry">Food Industry</option>
                        <option value="Dairy Industry">Dairy Industry</option>
                        <option value="Detergents Industry">Detergents Industry</option>
                        <option value="Educational Industry">Educational Industry</option>
                    </select>
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Job role</label>
                
                <select  name="otherinfo[jobrole]">
                <option>----</option>
                <option value="Cheif Executive">Cheif Executive Officer</option>
                <option value="Owner">Owner</option>
                <option value="General Manager">General Manager</option>
                <option value="Quality Manager">Quality Manager</option>
                <option value="IMS Manager">IMS Manager</option>
                <option value="R & D Manager">R & D Manager</option>
                </select>
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Product | Services *</label>
                <select name="otherinfo[prdoduct_services]">
                <option>----</option>
                <option value="Training">Training</option>
                <option value="Consultancy">Consultancy</option>
                <option value="Certifications">Certifications</option>
                <option value="Awards">Awards</option>
                <option value="Membership">Membership</option>
                <option value="Others">Others</option>
                </select>
                </div>
                <div class="col-md-4 col-xs-12">
                <label>Product Mode *</label>
                <select   name="otherinfo[prdoduct_mode]">
                <option>----</option>
                <option value="On-site Training">On-site Training</option>
                <option value="On-site Conusultancy">On-site Conusultancy</option>
                <option value="On-site Certifications">On-site Certifications</option>
                <option value="Online Training">Online Training</option>
                <option value="Online Conusultancy">Online Conusultancy</option>
                <option value="Awards">Awards</option>
                <option value="Others">Others</option>
                </select>
                </div>
                <div class="col-md-12 col-xs-12">
                <label>Attachment .....</label>
                <input class="form-control" type="file" name="image" id="image"> 
                </div>
                
                <div class="col-md-12 col-xs-12">
                <label>Message</label>
                <textarea class="form-control"  rows="5" name="message"></textarea>
                <p> <input type="checkbox" width="30" style="
    margin: 3px 8px 0 0px;
    display: inline-block;
    float: left;
"> I read, understand and agreed with all terms and conditions!
                </p>
                 </br>
                    <div class="page-alert" style="display: block;"></div>
                    </br>
                </div>
                
                <!--<input type="submit" name="btnSubmit" class="register pull-right" value="Submit">-->
                <input type="submit" class="btnCustom" value="Submit">
               
                </section>
			</form>
           </div>
           </div>
           </div>
        </section>
        
        
<?php include_once"footer.php"; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
function getDirection(val){
	if(val!=''){
		$('.USA,.EUROPE,.SOUTH,.MIDDLE,.AMERICA').addClass('hidden');
			$('.'+val).removeClass('hidden');
		}
	}
	

  /**********************************save************************************/
	 $('#form1').on("submit",function(e) {
		e.preventDefault();
		
		var formData = new FormData();
		var other_data = $('#form1').serializeArray();
		$.each(other_data,function(key,input)
		{
			formData.append(input.name,input.value);
		});  
		 formData.append("image", document.getElementById('image').files[0]);	 
	// ajax start
		    $.ajax({
			type: "POST",
			url: "<?php echo base_url().'contact/saveContactForm'; ?>",
			data: formData,
			cache: false,
			contentType: false,
			processData: false,
			dataType: 'JSON',
			beforeSend: function() {
			$('#loader').removeClass('hidden');
		//	$('#form_add_update .btn_au').addClass('hidden');
			},
			success: function(data) {
			$('#loader').addClass('hidden');
			//$('#form_add_update .btn_au').removeClass('hidden');
			//alert(data.status);
			//var obj = jQuery.parseJSON(data);
            if (data.status == 1)
            {   
			  //$("#mmmbershipID").val(aMessage[1]);
				//alert('mmmbershipID'+$("#mmmbershipID").val());
				getMsg('success',data.message);
				//$("#registrationDetail").hide();
				//$("#PaymentDetail").slideDown('slow');
            }
           else if (data.status ==0)
            {  
			  getMsg('error',data.message);
            }
			
			
           }
	 });

	//ajax end    
    });
   
   function getMsg(type,msg)
	{
			var msgg = '<div class="message"><p class="'+type+'">'+msg+'</p></div>';
			$(".page-alert").show();
			$(".page-alert").addClass('error');
			$(".page-alert").html(msgg);
			$(".page-alert").focus();
			setTimeout(function()
			{
				$(".page-alert").fadeOut().html('');
			},10000);	
	}
</script>
