<?php 
include_once"header.php";
?>
        
        <section id="sub-header" style="background:url(uploads/3682486280088.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
            <h1>History
            </h1>
</div>
            </div><!-- End row -->
        </div><!-- End container -->
      </section>
        <section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1488790902404" id="main-features">
            <div class="container">
            <img src="frontend/history.jpeg" class="img-responsive">
            </div>
<div class="container hidden">
    <div class="page-header">
        <h2 id="timeline">CPPEx GLOBAL IN THE COURSE OF TIME</h2>
    </div>
    <ul class="timeline">
        <li>
          <div class="timeline-badge"><i class="glyphicon glyphicon-check"></i><span class="bgPurple"> 2005</span></div>
          <div class="timeline-panel bg-info">
            <div class="timeline-heading">
              <h4 class="timeline-title">Training & Consultancy</h4>
              <p><small class="text-muted"></small></p>
            </div>
            <div class="timeline-body">
              <p>Establishment of CPPEx GLOBAL</p>
            </div>
          </div>
        </li>
        <li class="timeline-inverted">
          <div class="timeline-badge warning"><i class="glyphicon glyphicon-credit-card"></i><span class="bgGreen"> 2008</span></div>
          <div class="timeline-panel bg-danger">
            <div class="timeline-heading">
              <h4 class="timeline-title">Started Certification</h4>
            </div>
            <div class="timeline-body">
              <p>Entry into the market of Europe</p>
             
            </div>
          </div>
        </li>


        <li>
          <div class="timeline-badge"><i class="glyphicon glyphicon-check"></i><span class="bgPurple"> 2010</span></div>
          <div class="timeline-panel bg-warning">
            <div class="timeline-heading">
              <h4 class="timeline-title">Started Certificaion</h4>
              <p><small class="text-muted"></small></p>
            </div>
            <div class="timeline-body">
             <p>Entry into the market of Middle East & Europe</p>
              </div>
          </div>
        </li>
        <li class="timeline-inverted">
          <div class="timeline-badge warning"><i class="glyphicon glyphicon-credit-card"></i><span class="bgGreen"> 2015</span></div>
          <div class="timeline-panel bg-success">
            <div class="timeline-heading">
              <h4 class="timeline-title">Started Certification</h4>
            </div>
            <div class="timeline-body">
              <p>Entry into the market of South Americe</p>
             
            </div>
          </div>
        </li>


        <li>
          <div class="timeline-badge"><i class="glyphicon glyphicon-check"></i><span class="bgPurple"> 2017</span></div>
          <div class="timeline-panel bg-success">
            <div class="timeline-heading">
              <h4 class="timeline-title">Best Machine Operator Award</h4>
              <p><small class="text-muted"></small></p>
            </div>
            <div class="timeline-body">
             <p>Entry into the market of South Asia</p>
              </div>
          </div>
        </li>
        <li class="timeline-inverted">
          <div class="timeline-badge warning"><i class="glyphicon glyphicon-credit-card"></i><span class="bgGreen"> 2021</span></div>
          <div class="timeline-panel bg-info">
            <div class="timeline-heading ">
              <h4 class="timeline-title">Plan to expand in the market of centeral asia</h4>
            </div>
            <div class="timeline-body">
             
            </div>
          </div>
        </li>
         <li>
          <div class="timeline-badge"><i class="glyphicon glyphicon-check"></i><span class="bgPurple"> 2025</span></div>
          <div class="timeline-panel bg-warning">
            <div class="timeline-heading ">
              <h4 class="timeline-title">Plan to expand in New Zealand & Australia</h4>
              <p><small class="text-muted"></small></p>
            </div>
            <div class="timeline-body">
              </div>
          </div>
        </li>
    </ul>
</div>
        </section>
        
<?php include_once"footer.php"; ?>