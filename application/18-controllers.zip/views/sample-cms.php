<?php 
include_once"header.php";
?>
        <section id="sub-header">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
                    <h1>MEMBERSHIP APPLICATION
</h1>
CENTER OF PRINTING AND PACKAGING EXCELLENCE
</div>
            </div><!-- End row -->
        </div><!-- End container -->
      </section>
      <div class="clearfix">&nbsp;</div>
<section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1488790902404 " id="main-features">
            <div class="container"></div>
        </section>
        
        
<?php include_once"footer.php"; ?>
