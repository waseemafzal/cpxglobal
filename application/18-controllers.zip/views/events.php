<?php 
include_once"header.php";
?>
        <section id="sub-header" style="background:url(frontend/events.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
                    <h1>events
</h1>
</div>
            </div><!-- End row -->
        </div><!-- End container -->
      </section>
      <div class="clearfix">&nbsp;</div>
<section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1488790902404 " id="main-features">
           

<div class="container">
 <h4>Training Details</h4>
<table class="table   table-bordered ">
	<tbody>
		<tr style="background-color:#f30100 !important; color:#fff">
			<th colspan="1" rowspan="1">
			Course ID
			</th>
			<th colspan="1" rowspan="1">
			Training Title
			</th>
			<th colspan="1" rowspan="1">
			Location
			</th>
			<th colspan="1" rowspan="1">
			Training Date
			</th>
			<th colspan="1" rowspan="1">
			Registration Start
			</th>
			<th colspan="1" rowspan="1">
			Registration Closed
			</th>
			<th colspan="1" rowspan="1">
			Fee
			</th>
			<th colspan="1" rowspan="1">
			More Details
			</th>
		</tr>
		<tr>
			<td colspan="1" rowspan="1">
			<p>CG0001</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>Print Automation and Digitalization</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>New Jersey- USA</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>24-25 June-2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>20- May-2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>15- June- 2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>-</p>
			</td>
			<td align="center" colspan="1" rowspan="1">
			<a ><i class="fa fa-plus"></i></a>
			</td>
		</tr>
        <tr>
			<td colspan="1" rowspan="1">
			<p>CG0001</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>Print Automation and Digitalization</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>New Jersey- USA</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>24-25 June-2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>20- May-2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>15- June- 2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>-</p>
			</td>
			<td align="center" colspan="1" rowspan="1">
			<a ><i class="fa fa-plus"></i></a>
			</td>
		</tr>
        <tr>
			<td colspan="1" rowspan="1">
			<p>CG0001</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>Print Automation and Digitalization</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>New Jersey- USA</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>24-25 June-2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>20- May-2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>15- June- 2020</p>
			</td>
			<td colspan="1" rowspan="1">
			<p>-</p>
			</td>
			<td align="center" colspan="1" rowspan="1">
			<a ><i class="fa fa-plus"></i></a>
			</td>
		</tr>
	</tbody>
</table>
</div>


        </section>
        
        
<?php include_once"footer.php"; ?>


