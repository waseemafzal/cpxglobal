<?php 
include_once"header.php";
?>
        
        <section class="vc_rows wpb_rows vc_rows-fluid vc_custom_1464078186411" id="testimonials">
            <div class="container">
                <div class="row">
                    <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-md-offset-2 vc_col-md-8">
                        <div class="vc_column-inner">
                            <div class="wpb_wrapper">
                                <div class="wpb_text_column wpb_content_element">
                                    <div class="wpb_wrapper">
                                        <h2 style="text-align: center;">404 PAGE NOT FOUND</h2>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php include_once"footer.php"; ?>